setwd("/home/sathvik/Documents/CENTRE OF EXCELLENCE Project")
dataset = read.csv('default_credit5.csv')
library(ggplot2)
library(ggplot2)
library(ggpubr)
#install.packages("PRROC")
require(PRROC)
#install.packages('Plotly')
#library(plotly)
#packageVersion('plotly')
theme_set(theme_pubr())
a=dataset[,c(2,3,4,5,6,7,13,19,25)]
dataset1 = dataset[,c(2,3,4,5,6,7,13,19,25)]

# Encoding the target feature as factor
dataset$default.payment.next.month = factor(dataset$default.payment.next.month, levels = c(0, 1))

#Encoding the Independent Variables as Factors
dataset1$SEX = factor(dataset1$SEX, levels = c(1,2))
dataset1$EDUCATION = factor(dataset1$EDUCATION, levels = c(1,2,3,4))
dataset1$MARRIAGE = factor(dataset1$MARRIAGE, levels = c(1, 2, 3))
dataset1$PAY_0 = factor(dataset1$PAY_0, levels = c(0, 1, 2, 3, 4, 5, 6, 7, 8))
# dataset$PAY_2 = factor(dataset$PAY_2, levels = c(0, 1, 2, 3, 4, 5, 6, 7, 8))
# dataset$PAY_3 = factor(dataset$PAY_3, levels = c(0, 1, 2, 3, 4, 5, 6, 7, 8))
# dataset$PAY_4 = factor(dataset$PAY_4, levels = c(0, 1, 2, 3, 4, 5, 6, 7, 8))
# dataset$PAY_5 = factor(dataset$PAY_5, levels = c(0, 1, 2, 3, 4, 5, 6, 7, 8))
# dataset$PAY_6 = factor(dataset$PAY_6, levels = c(0, 1, 2, 3, 4, 5, 6, 7, 8))
# dataset
z <- summary(dataset1)
z1 <- as.data.frame.matrix(z)
# dz1 = data.frame(summary(dataset))
# dz1
# Splitting the dataset into the Training set and Test set
# install.packages('caTools')
library(caTools)
set.seed(123) 
split = sample.split(dataset1$default.payment.next.month, SplitRatio = 0.75)
split
training_set = subset(dataset1, split == TRUE)
test_set = subset(dataset1, split == FALSE)

# Feature Scaling
training_set[,c(1,5,7,8)] = scale(training_set[, c(1,5,7,8)])
test_set[, c(1,5,7,8)] = scale(test_set[, c(1,5,7,8)]) 
#dataset[,c(1,5,12,13)] = scale(dataset[, c(1,5,12,13)])
#dataset
dataset1
write.csv(dataset1, 'feed_dashboard.csv')
#Fitting Logistic Regression to the Training set
classifier = glm(formula = default.payment.next.month ~ .,
                 family = binomial,
                 data = training_set)

# # Predicting the Test set results
prob_pred = predict(classifier, type = 'response', newdata = test_set[-14])
y_pred = ifelse(prob_pred > 0.5, 1, 0)

#Building the optimal model using Backward Elimination
myForm <- as.formula(default.payment.next.month~
                       LIMIT_BAL +as.factor(SEX)+as.factor(EDUCATION)+as.factor(MARRIAGE)
                     + AGE +as.factor(PAY_0)+BILL_AMT1
                     + PAY_AMT1)
myForm
sofNoMis <- dataset1[which(complete.cases(dataset1[,all.vars(myForm)])),]
gc()
FulMod2 <- glm(myForm,family=binomial(link="logit"),data=sofNoMis)
FulMod2
library(caret)
library(C50)
# mod2 <- train(default.payment.next.month ~ ., data = dataset1, method = "C5.0Tree")
# l1 = varImp(mod2)
# l2 = summary(mod2)
# l1
# l2




b1 = summary(FulMod2)
b1
#dz2 = as.data.frame.matrix(FulMod2)
#Repeat the Process
# Making the Confusion Matrix
cm = table(test_set[ ,9], y_pred > 0.5)
summary(cm)
z3 <- as.data.frame.matrix(cm)

rownames(z3) <- c("TRUE","FALSE")
colnames(z3) <- c("TRUE","FALSE")
z3

#Apply K-Fold Cross Validation
#install.packages('caret')
library(caret)
folds = createFolds(training_set$default.payment.next.month, k=10)
cv = lapply(folds, function(x) {
  training_fold = training_set[-x, ]
  test_fold = test_set[x, ]  
  classifier = glm(formula = default.payment.next.month ~ .,
                   family = binomial,
                   data = training_fold)
  prob_pred = predict(classifier, type = 'response', newdata = test_fold[-9])
  y_pred = ifelse(prob_pred > 0.5, 1, 0)
  cm = table(test_fold[,9], y_pred > 0.5)
  accuracy = (cm[1,1] + cm[2,2]) / (cm[1,1] + cm[2,2] + cm[1,2] + cm[2,1])
  return(accuracy)
})
cv
f=as.data.frame(cv)
accuracy = mean(as.numeric(cv))
accuracy
#precision
#recall
#PRECISION , rECALL
#Applying Grid Search to find the best parameters
#library(caret)
#install.packages("e1071")
#install.packages("RWeka)
#library(e1071)
#library(RWeka)  output$plot_basic <- renderPlot({
# print(input$axis1)
# print(dim(dataset))
# ggplot(dataset, aes(dataset[,input$axis1])) +
#   geom_bar(fill = "#0073C2FF") +
#   theme_pubclean()

#library(LiblineaR)
#classifier = train(form = default.payment. next.month ~., data = training_set, method = 'LogitBoost')
#'logicBag', 'LogitBoost', 'logreg' , 'LMT', 'regLogistic' 
#classifier$bestTune                    # nIter = 21
#save(classifier, file = 'test1.csv') """

#ROCR Curve
library(PRROC)
fg <- prob_pred[test_set$default.payment.next.month == 1]
bg <- prob_pred[test_set$default.payment.next.month == 0]

# ROC Curve    
roc <- roc.curve(scores.class0 = fg, scores.class1 = bg, curve = T)

# PR Curve
pr <- pr.curve(scores.class0 = fg, scores.class1 = bg, curve = T)



# Visualising results
d1 = dataset %>% group_by(default.payment.next.month) %>% summarise(default.number = n())
d1$default.payment.next.month <- as.factor(d1$default.payment.next.month)

library(dplyr)
dataset <- dataset %>%group_by(default.payment.next.month) %>% summarise(counts = n())
dataset$default.payment.next.month <- as.factor(dataset$default.payment.next.month)
##---------------------------------------------ui------------------------------------------------##

dataset2 <- read.csv("feed_dashboard.csv")
library(shiny)
library(shinydashboard)
library(DT)
dataset = read.csv('default_credit5.csv')

if (interactive()) {
ui <- dashboardPage(skin = 'blue',
                    dashboardHeader(title = 'CREDIT DEFAULTRS',
                                    dropdownMenu(type = 'message',
                                                 messageItem(from = 'Balance Limit for Customers',
                                                             message = 'Defaulter'),
                                                 messageItem(from = 'Pay Status of Customers ',
                                                             message = 'Regular or Not' )),
                                    dropdownMenu(type = 'notifications',
                                                 notificationItem(
                                                   text = 'Tabs to be added',status = 'success'),
                                                 notificationItem(text = 'To be Connected to Server',
                                                                  status = 'warning')),
                                    dropdownMenuOutput('msgoutput'),
                                    dropdownMenu(type = 'task', taskItem(value = 80, color = 'aqua','DashBoard Optimization'),
                                                 taskItem(value = 55,color = 'red','Data Analysis'),
                                                 taskItem(value = 40, color = 'green', 'Classification using Machine Learning'))),
                    
                    dashboardSidebar( #disable = F,collapsed = T,
                      sidebarMenu(
                        menuItem('Basic Representation', tabName = "Representation", icon = icon("bar-chart-o"),badgeLabel = "New", badgeColor = "green"),
                        menuItem("Model", tabName = "Model2", icon =  icon("bullhorn"), badgeLabel = "New", badgeColor = "green")
                        
                      )
                    ),
                    
                    dashboardBody(
                      tabItems(
                        tabItem(tabName = "Representation",
                                fluidPage(
                                  headerPanel('Data REPRESENTATION'),
                                  mainPanel(
                                    tabsetPanel(type = "tab",
                                                tabPanel("UNIVARIATE", "CATEGORICAL   VARIABLE   DISTRIBUTION", 
                                                         selectInput("response1","Select  Categorical  Value  Attributes:",choices = colnames(dataset[!sapply(df,is.numeric)])),
                                                         radioButtons("categaric","Choose Categoric Representation",choices = c("Bar_Chart","Pie_Chart")),
                                                         plotOutput("Graphs1"),
                                                         "CONTINIOUS   VARIABLE   DISTRIBUTION", plotOutput('plot_basic1'),
                                                         selectInput('axis2','Select Continious Value Attributes', choices = colnames(dataset[,c(2,13,14,15,16,17,18,19,20,21,22,23,24,25)]),selected = 'LIMIT_BAL')),
                                                tabPanel("BI-VARIATE", "Detailed Analysis", plotOutput('plot_1Column_Bar'),
                                                         selectInput('xaxis','select the value for X Axis', choices = colnames(dataset),selected = 'default.payment.next.month'),
                                                         selectInput('yaxis','Select the value for Y Axis', choices =  colnames(dataset[,c(2,13,14,15,16,17,18,19,20,21,22,23,24)]),selected = 'LIMIT_BAL'),
                                                         selectInput('zaxis','Select the value for Z Axis', choices = c('mean', 'sum', 'median', 'sd','min', 'max'), selected = "mean")),
                                                tabPanel("TABLE", "TABLE HEAD",dataTableOutput("pat0"),actionButton("Summary",label= "TABLE SUMMARY",icon("refresh")), dataTableOutput("value"))
                                    )))
                                
                        ),
                        tabItem(tabName = "Model2",
                                fluidPage(
                                  headerPanel("SELECTION AND MODELLING"),
                                  mainPanel(
                                    tabsetPanel(type = "tab",
                                                tabPanel("PARAMETER SELECTIONS",p("Select the inputs for the Dependent Variable"),
                                                         selectInput(inputId = "DepVar", label = "Dependent Variables", multiple = FALSE, choices = colnames(dataset2[10])),
                                                         p("Select the inputs for the Independent Variable"),
                                                         checkboxGroupInput(inputId = "IndVar", label = "Independent Variables",choices = colnames(dataset2[-10])),
                                                         uiOutput("valuebox"),
                                                         verbatimTextOutput(outputId ="fitting"),
                                                         verbatimTextOutput(outputId = "RegSum")
                                                         #tableOutput("RegSum1")
                                                         #verbatimTextOutput(outputId = "IndPrint"),
                                                         #verbatimTextOutput(outputId = "DepPrint")
                                                         #dataTableOutput("rendered_file"),dataTableOutput("rendered_file1")
                                                         ),
                                                tabPanel("OPTIMAL MODEL", actionButton("Matrix",label= "CONFUSION MATRIX REPRESENTATION",icon("refresh")), 
                                                         tableOutput("pat3"),actionButton("ACCURACY",label= "K-FOLD ACCURACY & AGGREGATION",icon("refresh")), tableOutput("pat4"), 
                                                         #actionButton("variable",label= "SIGNIFICANT VARIABLE FINDING",icon("refresh")), verbatimTextOutput("pat5"),
                                                         actionButton("ROCAUC",label= "OPTIMAL ROC-AUC CURVE",icon("refresh")),plotOutput("pat2"),
                                                         actionButton("PRAUC",label= "OPTIMAL PR-AUC CURVE",icon("refresh")),plotOutput("pat8"))
                                    )
                                  )
                                )
                        )
                        
                        
                      )))




server <- function(input, output, session){
  
  output$plot_1Column_Bar <- renderPlot({
    
    bar2 <- tapply(dataset[,input$yaxis],list(dataset[,input$xaxis]),input$zaxis)
    barplot(bar2, xlab = input$xaxis, ylab = input$yaxis, col ='red', width =1, legend.text = "Comparison of two Variables")
  })
  
  output$Graphs1<-renderPlot({
    if(input$categaric == "Bar_Chart"){
      barplot(table(dataset[,input$response1]), main=input$response1,xlab=" ",ylab = "count",border="Blue", col="green")
    }
    
    if(input$categaric =='Pie_Chart'){
      pie(table(dataset[input$response1]), main=input$response1,xlab=" ",ylab = "count",border="Blue", col = c("purple", "violetred1", "green3",
                                                                                                               "cornsilk", "cyan", "white"))
    }
  })  
  
  output$plot_basic1 <- renderPlot({
    print(input$axis2)
    print(dim(dataset))
    ggplot(dataset, aes(dataset[,input$axis2])) +
      geom_histogram(fill = "#0073C2FF", bins = 30, xlab=input$axis2, ylab = "count", border="Blue", col="green") +
      theme_pubclean()
  })
  
  output$pat0 <- renderDataTable({
    a
  })
  
  data <- eventReactive(input$Summary,{
    # if(is.null(input$refresh1)){
    #   return()
    # }
    z1
  })
  
  output$value <-renderDataTable({
    data()
  })
  
  
  data1 <- eventReactive(input$ModelSummary,{
    # if(is.null(input$refresh1)){
    #   return()
    # }
    b1
  })
  
  output$pat1 <-renderPrint({
    data1()
  })
  
  
  data2 <- eventReactive(input$ROCAUC,{
    # if(is.null(input$refresh1)){
    #   return()
    # }
    # plot(ROCRperf, colorize = TRUE, print.cutoffs.at=seq(0,1,by=0.1), text.adj=c(-0.2,1.7))
    # abline(0, 1, col= "black")
    plot(roc, colorize = TRUE, print.cutoffs.at=seq(0,1,by=0.1), text.adj=c(-0.2,1.7))
  })
  
  output$pat2 <-renderPlot({
    data2()
  })
  
  data8 <- eventReactive(input$PRAUC,{
    # if(is.null(input$refresh1)){
    #   return()
    # }
    # plot(ROCRperf, colorize = TRUE, print.cutoffs.at=seq(0,1,by=0.1), text.adj=c(-0.2,1.7))
    #abline(0, 1, col= "black")
    plot(pr)
  })
  
  output$pat8 <-renderPlot({
    data8()
  })
  
  
  data3 <- eventReactive(input$Matrix,{
    # if(is.null(input$refresh1)){
    #   return()
    # }
    z3
  })
  
  output$pat3 <-renderTable({
    data3()
  })
  
  data4 <- eventReactive(input$ACCURACY,{
    # if(is.null(input$refresh1)){
    #   return()
    # }
    d = c(f, accuracy)
  })
  
  output$pat4 <-renderTable({
    data4()
  })
  
  data5 <- eventReactive(input$variable,{
    # if(is.null(input$refresh1)){
    #   return()
    # }
    l1
  })
  
  output$pat5 <-renderPrint({
    data5()
  })
  
  # output$val1 <-renderTable({
  #   SplitRatio 
  # })
  
  df <- reactive({
    req(input$uploaded_file)
    read.csv(input$uploaded_file$datapath,
             header = input$header,
             sep = input$sep)  
    
  })
  # Dynamically generate UI input when data is uploaded ----
  output$checkbox <- renderUI({
    checkboxGroupInput(inputId = "select_var", 
                       label = "Select regressors", 
                       choices = names(df()))
  })
  
  output$checkbox1 <- renderUI({
    checkboxGroupInput(inputId = "select_var_Y", 
                       label = "Select one target variable", 
                       choices = "default.payment.next.month")
  })
  
  # Select columns to print ----
  df_sel <- reactive({
    req(input$select_var)
    df_sel <- df() %>% select(input$select_var)
  })
  
  # Print data table ----  
  output$rendered_file <- DT::renderDataTable({
    if(input$disp == "head") {
      head(df_sel())
    }
    else {
      df_sel()
    }
  })
  
  # Select columns to print ----
  df_sel1 <- reactive({
    req(input$select_var_Y)
    df_sel1 <- df() %>% select(input$select_var_Y)
  })
  
  # Print data table ----  
  output$rendered_file1 <- DT::renderDataTable({
    if(input$disp == "head") {
      head(df_sel1())
    }
    else {
      df_sel1()
    }
  })
 
  output$valuebox <- renderUI({
    sliderInput("sample_split", "Set the Training/Testing Splits:",
                 min = 0.05, max = 1,
                 value = 0.7, step =0.05)
  })
  
  inTrain <- reactive({sample(seq_len(nrow(dataset2)), size = nrow(dataset2)*input$sample_split)})
  
  # subset
  train <- reactive({dataset2[inTrain(), ]})
  test <- reactive({dataset2[-inTrain(), ]})
  
  lm1 <- reactive({glm(reformulate(input$IndVar, input$DepVar), family = "binomial",data = train())})

  
  predab <- reactive({predict(lm1(), type = "response", newdata = test())})
  
  pred1a <- reactive({ifelse(predab() > 0.5, 1, 0)})
  
  output$DepPrint <- renderPrint({input$DepVar})
  output$IndPrint <- renderPrint({input$IndVar})
  output$fitting <- renderPrint({lm1()})
  output$RegSum <- renderPrint({summary(predab())})
  #output$RegSum1 <- renderTable({pred1a()})
  
}

# Run the applicatiaon 
shinyApp(ui = ui, server = server)

}


